=== Gravity Forms Javascript Validation ===
Contributors: benhays
Donate link: 
Tags: gravity forms, gravityforms, validation, jquery validate, form validation
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enable front end javascript validation to Gravity Forms

== Description ==

Enable front end javascript validation to Gravity Forms

Currently only works for single page forms.

== Installation ==

1. Install as a regular WordPress plugin
2. Create a form with Gravity Forms
3. Toggle the Javascript Validation checkbox under Form Settings

== Frequently asked questions ==

= Can I change what the error display looks like? =

Yes, however, that's currently only possible by adding your own CSS to the theme.

== Screenshots ==

== Changelog ==

### 1.0
* Initial release with jQuery Validate 1.11.1

== Upgrade notice ==
<?php
/*
	Plugin Name: MHI Functionality Plugin
	Description: Adds Clinical Studies and Physicians post types and taxonomies to WordPress, along with a template tag and shortcode to query this content.
	Author: Gerry Yumul / Josh Leuze
	Author URI: http://jleuze.com/
	License: GPL2
	Version: 1.0
*/

/*  Copyright 2014 Josh Leuze (email : mail@jleuze.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

	// Adds custom post type for Clinical Studies
	function mhi_register_clinical_studies() {

		// Sets the labels that are used in the WordPress admin for this CPT
		$mhi_labels = array(
			'name'               => __( 'Clinical Studies', 'mhi' ),
			'singular_name'      => __( 'Clinical Study', 'mhi' ),
			'menu_name'          => __( 'Clinical Studies', 'mhi' ),
			'name_admin_bar'     => __( 'Clinical Study', 'mhi' ),
			'add_new'            => __( 'Add New', 'mhi' ),
			'add_new_item'       => __( 'Add New Clinical Study', 'mhi' ),
			'new_item'           => __( 'New Clinical Study', 'mhi' ),
			'edit_item'          => __( 'Edit Clinical Study', 'mhi' ),
			'view_item'          => __( 'View Clinical Study', 'mhi' ),
			'all_items'          => __( 'All Clinical Studies', 'mhi' ),
			'search_items'       => __( 'Search Clinical Studies', 'mhi' ),
			'parent_item_colon'  => __( 'Parent Clinical Study:', 'mhi' ),
			'not_found'          => __( 'No Clinical Studies found', 'mhi' ),
			'not_found_in_trash' => __( 'No Clinical Studies found in Trash', 'mhi' ), 
		);

		// Sets the role capabilities for the CPT, in this case authors and above can manage this CPT
		$mhi_capabilities   = array(
			'edit_post'          => 'edit_post',
			'edit_posts'         => 'edit_posts',
			'edit_others_posts'  => 'edit_others_posts',
			'publish_posts'      => 'publish_posts',
			'read_post'          => 'read_post',
			'read_private_posts' => 'read_private_posts',
			'delete_post'        => 'delete_post'
		);

		// The arguments for this CPT which setup what functionality it has in the post editor, etc.
		$mhi_args = array(
			'labels'              => $mhi_labels,
			'public'              => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'show_ui'             => true,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => true,
			'menu_icon'           => 'dashicons-clipboard',
			'capability_type'     => 'post',
			'capabilities'        => $mhi_capabilities,
			'map_meta_cap'        => true,
			'hierarchical'        => false,
			'menu_position'       => 4,
			'supports'            => array( 'author', 'title', 'editor' ),
			'taxonomies'          => array( 'status', 'condition', 'mhif-section', 'study-type', 'sponsor' ),
			'has_archive'         => true,
			'rewrite'             => array( 'slug' => 'clinical-studies' ),
			'query_var'           => true,
			'can_export'          => true
		);
  
  		// Register the Clinical Studies custom post type
		register_post_type( 'clinical-studies', $mhi_args );
		register_taxonomy_for_object_type( 'category', 'clinical-studies' );
		register_taxonomy_for_object_type( 'post_tag', 'clinical-studies'  );
		
	}
	add_action( 'init', 'mhi_register_clinical_studies' );

	// Adds custom post type for People
	function mhi_register_people() {

		// Sets the labels that are used in the WordPress admin for this CPT
		$mhi_labels = array(
			'name'               => __( 'People', 'mhi' ),
			'singular_name'      => __( 'Person', 'mhi' ),
			'menu_name'          => __( 'People', 'mhi' ),
			'name_admin_bar'     => __( 'People', 'mhi' ),
			'add_new'            => __( 'Add New', 'mhi' ),
			'add_new_item'       => __( 'Add New Person', 'mhi' ),
			'new_item'           => __( 'New Person', 'mhi' ),
			'edit_item'          => __( 'Edit Person', 'mhi' ),
			'view_item'          => __( 'View Person', 'mhi' ),
			'all_items'          => __( 'All People', 'mhi' ),
			'search_items'       => __( 'Search People', 'mhi' ),
			'parent_item_colon'  => __( 'Parent Person:', 'mhi' ),
			'not_found'          => __( 'No People found', 'mhi' ),
			'not_found_in_trash' => __( 'No People found in Trash', 'mhi' )
		);

		// Sets the role capabilities for the CPT, in this case authors and above can manage this CPT
		$mhi_capabilities   = array(
			'edit_post'          => 'edit_post',
			'edit_posts'         => 'edit_posts',
			'edit_others_posts'  => 'edit_others_posts',
			'publish_posts'      => 'publish_posts',
			'read_post'          => 'read_post',
			'read_private_posts' => 'read_private_posts',
			'delete_post'        => 'delete_post'
		);

		// The arguments for this CPT which setup what functionality it has in the post editor, etc.
		$mhi_args = array(
			'labels'              => $mhi_labels,
			'public'              => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'show_ui'             => true,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => true,
			'menu_icon'           => 'dashicons-businessman',
			'capability_type'     => 'post',
			'capabilities'        => $mhi_capabilities,
			'map_meta_cap'        => true,
			'hierarchical'        => false,
			'menu_position'       => 5,
			'supports'            => array( 'author', 'title', 'editor', 'excerpt', 'thumbnail' ),
			'taxonomies'          => array( 'specialty', 'condition', 'affiliation', 'position' ),
			'has_archive'         => true,
			'rewrite'             => array( 'slug' => 'people' ),
			'query_var'           => true,
			'can_export'          => true
		);
  
  		// Register the People custom post type
		register_post_type( 'people', $mhi_args );
		register_taxonomy_for_object_type( 'category', 'people' );
		register_taxonomy_for_object_type( 'post_tag', 'people'  );

		
	}
	add_action( 'init', 'mhi_register_people' );

	// Adds custom taxonomy for Status
	function mhi_register_status_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Statuses', 'mhi' ),
			'singular_name'              => __( 'Status', 'mhi' ),
			'menu_name'                  => __( 'Statuses', 'mhi' ),
			'all_items'                  => __( 'All Statuses', 'mhi' ),
			'edit_item'                  => __( 'Edit Status', 'mhi' ),
			'view_item'                  => __( 'View Status', 'mhi' ),
			'update_item'                => __( 'Update Status', 'mhi' ),
			'add_new_item'               => __( 'Add New Status', 'mhi' ),
			'new_item_name'              => __( 'New Status Name', 'mhi' ),
			'parent_item'                => __( 'Parent Status', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Status:', 'mhi' ),
			'search_items'               => __( 'Search Statuses', 'mhi' ),
			'popular_items'              => __( 'Popular Statuses', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Statuses with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Statuses', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Statuses', 'mhi' ),
			'not_found'                  => __( 'No Statuses found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'status' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Status custom taxonomy for the Clinical Studies custom post type
		register_taxonomy( 'status', 'clinical-studies', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_status_taxonomy' );

	// Adds custom taxonomy for Condition
	function mhi_register_condition_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Conditions', 'mhi' ),
			'singular_name'              => __( 'Condition', 'mhi' ),
			'menu_name'                  => __( 'Conditions', 'mhi' ),
			'all_items'                  => __( 'All Conditions', 'mhi' ),
			'edit_item'                  => __( 'Edit Condition', 'mhi' ),
			'view_item'                  => __( 'View Condition', 'mhi' ),
			'update_item'                => __( 'Update Condition', 'mhi' ),
			'add_new_item'               => __( 'Add New Condition', 'mhi' ),
			'new_item_name'              => __( 'New Condition Name', 'mhi' ),
			'parent_item'                => __( 'Parent Condition', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Condition:', 'mhi' ),
			'search_items'               => __( 'Search Conditions', 'mhi' ),
			'popular_items'              => __( 'Popular Conditions', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Conditions with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Conditions', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Conditions', 'mhi' ),
			'not_found'                  => __( 'No Conditions found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'condition' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Condition custom taxonomy for the Clinical Studies and People custom post types
		register_taxonomy( 'condition', array( 'clinical-studies', 'people' ), $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_condition_taxonomy' );


	// Adds custom taxonomy for MHIF Section
	function mhi_register_mhif_section_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'MHIF Sections', 'mhi' ),
			'singular_name'              => __( 'MHIF Section', 'mhi' ),
			'menu_name'                  => __( 'MHIF Sections', 'mhi' ),
			'all_items'                  => __( 'All MHIF Sections', 'mhi' ),
			'edit_item'                  => __( 'Edit MHIF Section', 'mhi' ),
			'view_item'                  => __( 'View MHIF Section', 'mhi' ),
			'update_item'                => __( 'Update MHIF Section', 'mhi' ),
			'add_new_item'               => __( 'Add New MHIF Section', 'mhi' ),
			'new_item_name'              => __( 'New MHIF Section Name', 'mhi' ),
			'parent_item'                => __( 'Parent MHIF Section', 'mhi' ),
			'parent_item_colon'          => __( 'Parent MHIF Section:', 'mhi' ),
			'search_items'               => __( 'Search MHIF Sections', 'mhi' ),
			'popular_items'              => __( 'Popular MHIF Sections', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate MHIF Sections with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove MHIF Sections', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used MHIF Sections', 'mhi' ),
			'not_found'                  => __( 'No MHIF Sections found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'mhif-section' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the MHIF Section custom taxonomy for the Clinical Studies custom post type
		register_taxonomy( 'mhif-section', 'clinical-studies', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_mhif_section_taxonomy' );

	// Adds custom taxonomy for Study Type
	function mhi_register_study_type_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Study Types', 'mhi' ),
			'singular_name'              => __( 'Study Type', 'mhi' ),
			'menu_name'                  => __( 'Study Types', 'mhi' ),
			'all_items'                  => __( 'All Study Types', 'mhi' ),
			'edit_item'                  => __( 'Edit Study Type', 'mhi' ),
			'view_item'                  => __( 'View Study Type', 'mhi' ),
			'update_item'                => __( 'Update Study Type', 'mhi' ),
			'add_new_item'               => __( 'Add New Study Type', 'mhi' ),
			'new_item_name'              => __( 'New Study Type Name', 'mhi' ),
			'parent_item'                => __( 'Parent Study Type', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Study Type:', 'mhi' ),
			'search_items'               => __( 'Search Study Types', 'mhi' ),
			'popular_items'              => __( 'Popular Study Types', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Study Types with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Study Types', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Study Types', 'mhi' ),
			'not_found'                  => __( 'No Study Types found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'study-type' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the MHIF Section custom taxonomy for the Study Type custom post type
		register_taxonomy( 'study-type', 'clinical-studies', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_study_type_taxonomy' );

	// Adds custom taxonomy for Sponsor
	function mhi_register_sponsor_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Sponsors', 'mhi' ),
			'singular_name'              => __( 'Sponsor', 'mhi' ),
			'menu_name'                  => __( 'Sponsors', 'mhi' ),
			'all_items'                  => __( 'All Sponsors', 'mhi' ),
			'edit_item'                  => __( 'Edit Sponsor', 'mhi' ),
			'view_item'                  => __( 'View Sponsor', 'mhi' ),
			'update_item'                => __( 'Update Sponsor', 'mhi' ),
			'add_new_item'               => __( 'Add New Sponsor', 'mhi' ),
			'new_item_name'              => __( 'New Sponsor Name', 'mhi' ),
			'parent_item'                => __( 'Parent Sponsor', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Sponsor:', 'mhi' ),
			'search_items'               => __( 'Search Sponsors', 'mhi' ),
			'popular_items'              => __( 'Popular Sponsors', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Sponsors with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Sponsors', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Sponsors', 'mhi' ),
			'not_found'                  => __( 'No Sponsors found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => false,
			'rewrite'           => array( 'slug' => 'sponsor' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Sponsor custom taxonomy for the Clinical Studies custom post type
		register_taxonomy( 'sponsor', 'clinical-studies', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_sponsor_taxonomy' );

	// Adds custom taxonomy for Specialty
	function mhi_register_specialty_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Specialties', 'mhi' ),
			'singular_name'              => __( 'Specialty', 'mhi' ),
			'menu_name'                  => __( 'Specialties', 'mhi' ),
			'all_items'                  => __( 'All Specialties', 'mhi' ),
			'edit_item'                  => __( 'Edit Specialty', 'mhi' ),
			'view_item'                  => __( 'View Specialty', 'mhi' ),
			'update_item'                => __( 'Update Specialty', 'mhi' ),
			'add_new_item'               => __( 'Add New Specialty', 'mhi' ),
			'new_item_name'              => __( 'New Specialty Name', 'mhi' ),
			'parent_item'                => __( 'Parent Specialty', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Specialty:', 'mhi' ),
			'search_items'               => __( 'Search Specialties', 'mhi' ),
			'popular_items'              => __( 'Popular Specialties', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Specialties with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Specialties', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Specialties', 'mhi' ),
			'not_found'                  => __( 'No Specialties found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'specialty' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Specialty custom taxonomy for the People custom post type
		register_taxonomy( 'specialty', 'people', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_specialty_taxonomy' );

	// Adds custom taxonomy for Affiliations
	function mhi_register_affiliation_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Affiliations', 'mhi' ),
			'singular_name'              => __( 'Affiliation', 'mhi' ),
			'menu_name'                  => __( 'Affiliations', 'mhi' ),
			'all_items'                  => __( 'All Affiliations', 'mhi' ),
			'edit_item'                  => __( 'Edit Affiliation', 'mhi' ),
			'view_item'                  => __( 'View Affiliation', 'mhi' ),
			'update_item'                => __( 'Update Affiliation', 'mhi' ),
			'add_new_item'               => __( 'Add New Affiliation', 'mhi' ),
			'new_item_name'              => __( 'New Affiliation Name', 'mhi' ),
			'parent_item'                => __( 'Parent Affiliation', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Affiliation:', 'mhi' ),
			'search_items'               => __( 'Search Affiliations', 'mhi' ),
			'popular_items'              => __( 'Popular Affiliations', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Affiliations with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Affiliations', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Affiliations', 'mhi' ),
			'not_found'                  => __( 'No Affiliations found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => false,
			'rewrite'           => array( 'slug' => 'affiliation' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Affiliation custom taxonomy for the People custom post type
		register_taxonomy( 'affiliation', 'people', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_affiliation_taxonomy' );

	// Adds custom taxonomy for Positions
	function mhi_register_position_taxonomy() {
	
		// Sets the labels that are used in the WordPress admin for this taxonomy
		$mhi_tax_labels = array(
			'name'                       => __( 'Positions', 'mhi' ),
			'singular_name'              => __( 'Position', 'mhi' ),
			'menu_name'                  => __( 'Positions', 'mhi' ),
			'all_items'                  => __( 'All Positions', 'mhi' ),
			'edit_item'                  => __( 'Edit Position', 'mhi' ),
			'view_item'                  => __( 'View Position', 'mhi' ),
			'update_item'                => __( 'Update Position', 'mhi' ),
			'add_new_item'               => __( 'Add New Position', 'mhi' ),
			'new_item_name'              => __( 'New Position Name', 'mhi' ),
			'parent_item'                => __( 'Parent Position', 'mhi' ),
			'parent_item_colon'          => __( 'Parent Position:', 'mhi' ),
			'search_items'               => __( 'Search Positions', 'mhi' ),
			'popular_items'              => __( 'Popular Positions', 'mhi' ),
			'separate_items_with_commas' => __( 'Separate Positions with commas', 'mhi' ),
			'add_or_remove_items'        => __( 'Add or remove Positions', 'mhi' ),
			'choose_from_most_used'      => __( 'Choose from the most used Positions', 'mhi' ),
			'not_found'                  => __( 'No Positions found', 'mhi' )
		);
		
		// Sets the role capabilities for the taxonomy, in this case authors and above can manage this taxonomy
		$mhi_tax_capabilities = array(
			'manage_terms' => 'manage_categories',
			'edit_terms'   => 'manage_categories',
			'delete_terms' => 'manage_categories',
			'assign_terms' => 'edit_posts'
		);
		
		// The arguments for this taxonomy whether it is hierarchical or non-hierarchical, etc.
		$mhi_tax_args = array(
			'labels'            => $mhi_tax_labels,
			'public'            => true,
			'show_ui'           => true,
			'show_in_nav_menus' => false,
			'show_tagcloud'     => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'position' ),
			'capabilities'      => $mhi_tax_capabilities
		);
	
		// Register the Position custom taxonomy for the People custom post type
		register_taxonomy( 'position', 'people', $mhi_tax_args );
		
	}
	add_action( 'init', 'mhi_register_position_taxonomy' );
	
	// Adds featured image functionality for the People CPT
	function mhi_featured_image_array() {
	
		global $_wp_theme_features;

		// If post thumbnails aren't setup for any post types, set them up for just the People CPT
		if ( !isset( $_wp_theme_features['post-thumbnails'] ) ) {
			$_wp_theme_features['post-thumbnails'] = array( array( 'people' ) );	
		}

		// If post thumbnails are already setup for other post types, add the People CPT to them
		elseif ( is_array( $_wp_theme_features['post-thumbnails'] ) ) {
			$_wp_theme_features['post-thumbnails'][0][] = 'people';
		}
		
	}
	add_action( 'after_setup_theme', 'mhi_featured_image_array', '9999' );
	
	// Adds featured image size for the People CPT
	function mhi_featured_image() {

		add_image_size( 'people-image', 200, 200 );

	}
	add_action( 'plugins_loaded', 'mhi_featured_image' );

	*/
	
	// Adds function to load custom post types in theme with a template tag
	function mhi_loop( $cpt='', $tax='', $term='', $quantity='' ) {

		include( 'includes/mhi_loop.php' );
	
	}
		
		/* To load content from the custom post types, add this template tag to your theme and edit the parameters:
	
			<?php if( function_exists( 'mhi_loop' ) ) { mhi_loop( "clinical-studies", "status", "enrolling", "5" ); } ?>
	
		*/
		
	// Adds shortcode to load custom post types in page content from the mhi_loop function
	function mhi_loop_shortcode( $mhi_atts ) {
	
		// Get the attributes from the shortcode
		extract( shortcode_atts( array (
			'cpt'      => '',
			'tax'      => '',
			'term'     => '',
			'quantity' => ''
		), $mhi_atts ) );
		
		// Setup the shortcode attributes for the mhi_loop function
		$cpt_att      = $cpt;
		$tax_att      = $tax;
		$term_att     = $term;
		$quantity_att = $quantity;
	
		// Pause the output of the shortcode
		ob_start();
		
		// Run the mhi_loop function that loads content from CPTs
		mhi_loop( $cpt=$cpt_att, $tax=$tax_att, $term=$term_att, $quantity=$quantity_att );
		
		// Resume the output of the shortcode with the contents of the mhi_loop function
		$mhi_loop_content = ob_get_clean();
		return $mhi_loop_content;
	
	}
	add_shortcode( 'mhi_loop', 'mhi_loop_shortcode' );
	
		/* To load content from the custom post types, add this shortcode to your page content and edit the parameters:
	
			[mhi_loop cpt="clinical-studies" tax="status" term="open-for-enrollment" quantity="5"]
	
		*/


/* Custom Website Roles*/
   function add_roles_on_plugin_activation() {
       	add_role( 'research-coordinator', 'Research Coordinator', $editor->capabilities );
	get_role('research-coordinator')->add_cap( 'edit_others_posts', 'edit_published_posts', 'edit_posts', 'delete_posts', 'delete_published_posts','publish_posts', 'read', 'upload_files' ); 
   }
   register_activation_hook( __FILE__, 'add_roles_on_plugin_activation' );

/* Remove Admin Bar Except for admin*/
add_action('after_setup_theme', 'remove_admin_bar');

function remove_admin_bar() {
if (!current_user_can('administrator') && !is_admin()) {
  show_admin_bar(false);
}
}

?>